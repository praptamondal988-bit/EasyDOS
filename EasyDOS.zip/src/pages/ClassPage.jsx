import { useNavigate, useParams } from "react-router-dom";
import subjects from "../data/subjects";
import "./ClassPage.css";
function ClassPage() {

  const navigate = useNavigate();

  const { className } = useParams();

  const classSubjects = subjects[className] || [];

  const icons = {
    Bangla: "📘",
    English: "🌍",
    Mathematics: "🧮",
    "General Mathematics": "🧮",
    "Higher Mathematics": "📐",
    Science: "🔬",
    Physics: "⚛️",
    Chemistry: "🧪",
    Biology: "🧬",
    ICT: "💻",
    BGS: "🌏"
  };

  return (

    <div className="class-page">

      <h1>
        📚 {className.toUpperCase()}
      </h1>

      <p>
        Select Your Subject
      </p>

      <div className="subject-grid">

        {classSubjects.map((subject) => (

          <div

            key={subject}

            className="subject-card"

            onClick={() =>
              navigate(
                `/class/${className}/${subject.toLowerCase().replace(/\s+/g,"-")}`
              )
            }

          >

            <div className="subject-icon">

              {icons[subject] || "📖"}

            </div>

            <h3>{subject}</h3>

          </div>

        ))}

      </div>

    </div>

  );

}

export default ClassPage;