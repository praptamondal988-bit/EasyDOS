import Achievements from "../components/Achievements";
import BannerSlider from "../components/BannerSlider";
import TopTeachers from "../components/TopTeachers";
import StudyStats from "../components/StudyStats";
import TrendingCourses from "../components/TrendingCourses";
import Header from "../components/Header";
import SearchBar from "../components/SearchBar";
import Hero from "../components/Hero";
import ContinueLearning from "../components/ContinueLearning";
import ClassSection from "../components/ClassSection";
import SubjectSection from "../components/SubjectSection";
import FeaturedCourses from "../components/FeaturedCourses";
import Footer from "../components/Footer";

function Home() {
  return (
    <>
      <Header />
      <SearchBar />
      <BannerSlider />
    <ContinueLearning />
      <ClassSection />
      <SubjectSection />
      <FeaturedCourses />
      <TrendingCourses />
      <TopTeachers />
      <StudyStats />
      <Achievements />
      <Footer />
    </>
  );
}
      
export default Home;