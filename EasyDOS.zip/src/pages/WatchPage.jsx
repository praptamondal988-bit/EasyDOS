import { saveWatch } from "../utils/watchHistory";
import { useParams, Link } from "react-router-dom";

function WatchPage() {

  const { youtubeId } = useParams();

  return (

    <div
      style={{
        width: "90%",
        maxWidth: "1200px",
        margin: "40px auto",
        color: "white"
      }}
    >

      <Link
        to="/"
        style={{
          color: "#60a5fa",
          textDecoration: "none"
        }}
      >
        ← Back
      </Link>

      <h1
        style={{
          marginTop: "20px",
          marginBottom: "30px"
        }}
      >
        🎥 Video Player
      </h1>

      <div
        style={{
          borderRadius: "20px",
          overflow: "hidden",
          background: "#111827"
        }}
      >

        <iframe
          width="100%"
          height="650"
          src={`https://www.youtube.com/embed/${youtubeId}`}
          title="EasyDOS Video"
          frameBorder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        ></iframe>

      </div>

    </div>

  );

}

export default WatchPage;