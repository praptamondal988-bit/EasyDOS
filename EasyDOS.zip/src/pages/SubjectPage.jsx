import { useNavigate, useParams } from "react-router-dom";

function SubjectPage() {

  const navigate = useNavigate();

  const { className, subjectName } = useParams();

  return (

    <div
      style={{
        width:"90%",
        maxWidth:"1200px",
        margin:"50px auto",
        color:"white"
      }}
    >

      <h1>
        📚 {className.toUpperCase()}
      </h1>

      <h2
        style={{
          marginTop:"15px",
          color:"#60a5fa"
        }}
      >
        {subjectName.toUpperCase()}
      </h2>

      <div
        style={{
          display:"grid",
          gridTemplateColumns:"repeat(auto-fit,minmax(250px,1fr))",
          gap:"25px",
          marginTop:"40px"
        }}
      >

        <div
          onClick={() =>
            navigate(`/videos/${className}/${subjectName}`)
          }
          style={{
            background:"#1f2937",
            padding:"35px",
            borderRadius:"20px",
            cursor:"pointer",
            textAlign:"center"
          }}
        >
          <div style={{fontSize:"60px"}}>🎥</div>
          <h3>Video Classes</h3>
        </div>

        <div
          style={{
            background:"#1f2937",
            padding:"35px",
            borderRadius:"20px",
            textAlign:"center"
          }}
        >
          <div style={{fontSize:"60px"}}>📄</div>
          <h3>PDF Notes</h3>
        </div>

        <div
          style={{
            background:"#1f2937",
            padding:"35px",
            borderRadius:"20px",
            textAlign:"center"
          }}
        >
          <div style={{fontSize:"60px"}}>📝</div>
          <h3>Quiz</h3>
        </div>

      </div>

    </div>

  );

}

export default SubjectPage;