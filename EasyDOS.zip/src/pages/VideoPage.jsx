import "./VideoPage.css";
import { useNavigate, useParams } from "react-router-dom";
import videos from "../data/videos";
import VideoCard from "../components/VideoCard";

function VideoPage() {

  const navigate = useNavigate();

  const { className, subjectName } = useParams();

  const videoList =
    videos[className]?.[subjectName] || [];

  return (

    <div className="video-page">

      <h1>
        🎥 {subjectName.toUpperCase()} Video Classes
      </h1>

      <p>
        Learn chapter by chapter with HD video lectures.
      </p>

      <div className="video-list">

        {videoList.length === 0 ? (

          <h2>No Videos Found</h2>

        ) : (

          videoList.map((video)=>(

            <VideoCard

              key={video.id}

              video={video}

              onClick={()=>

                navigate(`/watch/${video.youtubeId}`)

              }

            />

          ))

        )}

      </div>

    </div>

  );

}

export default VideoPage;