import { useParams } from "react-router-dom";

function LearningPage() {

  const { className, subjectName, feature } = useParams();

  return (

    <div
      style={{
        width: "90%",
        maxWidth: "1200px",
        margin: "50px auto",
        color: "white"
      }}
    >

      <h1>
        📚 {className.toUpperCase()}
      </h1>

      <h2
        style={{
          color: "#60a5fa",
          marginTop: "15px"
        }}
      >
        {subjectName.toUpperCase()}
      </h2>

      <h3
        style={{
          marginTop: "25px"
        }}
      >
        {feature.toUpperCase()}
      </h3>

      <div
        style={{
          marginTop: "40px",
          background: "#1f2937",
          padding: "40px",
          borderRadius: "20px",
          textAlign: "center"
        }}
      >

        <h2>
          🚧 Coming Soon
        </h2>

        <p>
          This section will contain real content.
        </p>

      </div>

    </div>

  );

}

export default LearningPage;