import "./ContinueLearning.css";

function ContinueLearning() {

  const courses = [
    {
      subject: "Physics",
      chapter: "Chapter 3 • Motion",
      progress: "70%"
    },
    {
      subject: "Chemistry",
      chapter: "Chapter 2 • Atom",
      progress: "45%"
    },
    {
      subject: "Biology",
      chapter: "Chapter 5 • Cell",
      progress: "90%"
    }
  ];


  return (
    <section className="continue-section">

      <h2>
        ▶ Continue Learning
      </h2>


      <div className="continue-grid">

        {courses.map((course)=>(
          <div 
          className="continue-card"
          key={course.subject}
          >

            <h3>
              {course.subject}
            </h3>


            <p>
              {course.chapter}
            </p>


            <div className="progress-bar">

              <div 
              className="progress"
              style={{
                width: course.progress
              }}
              ></div>

            </div>


            <span>
              {course.progress} Complete
            </span>


            <button>
              Resume
            </button>


          </div>
        ))}


      </div>


    </section>
  );
}


export default ContinueLearning;