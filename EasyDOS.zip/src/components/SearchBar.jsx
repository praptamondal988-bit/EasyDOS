import "./SearchBar.css";

function SearchBar() {
  return (
    <section className="search-section">
      <div className="search-container">
        <div className="search-box">
          <span className="search-icon">🔍</span>

          <input
            className="search-input"
            type="text"
            placeholder="Search Subjects, Classes, Notes, Videos..."
          />

          <button className="search-btn">
            Search
          </button>
        </div>
      </div>
    </section>
  );
}

export default SearchBar;