function Hero() {
  return (
    <section className="hero">

      <div className="hero-left">

        <span className="hero-badge">
          🚀 Bangladesh's Smart Learning Platform
        </span>

        <h1>
          Learn Smarter with <span>EasyDOS</span>
        </h1>

        <p>
          Watch video classes, read PDF notes, solve quizzes,
          and prepare for exams — all in one place.
        </p>

        <div className="hero-buttons">
          <button className="start-btn">▶ Start Learning</button>
          <button className="explore-btn">📚 Explore</button>
        </div>

      </div>

      <div className="hero-right">

        <div className="hero-card">
          <h2>📚 Today's Progress</h2>

          <div className="hero-progress">
            <p>Physics</p>
            <div className="progress">
              <div className="progress-fill" style={{ width: "80%" }}></div>
            </div>
          </div>

          <div className="hero-progress">
            <p>Chemistry</p>
            <div className="progress">
              <div className="progress-fill" style={{ width: "60%" }}></div>
            </div>
          </div>

          <div className="hero-progress">
            <p>Biology</p>
            <div className="progress">
              <div className="progress-fill" style={{ width: "40%" }}></div>
            </div>
          </div>

        </div>

      </div>

    </section>
  );
}

export default Hero;