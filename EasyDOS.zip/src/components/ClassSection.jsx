import "./ClassSection.css";
import { useNavigate } from "react-router-dom";

function ClassSection() {

  const navigate = useNavigate();

  const classes = [
    {
      name: "Class 6",
      icon: "📘",
    },
    {
      name: "Class 7",
      icon: "📗",
    },
    {
      name: "Class 8",
      icon: "📙",
    },
    {
      name: "Class 9",
      icon: "🎓",
    },
    {
      name: "Class 10",
      icon: "🏆",
    },
    {
      name: "SSC",
      icon: "📝",
    },
    {
      name: "HSC",
      icon: "🎯",
    },
    {
      name: "Admission",
      icon: "🚀",
    },
  ];

  const handleClick = (className) => {
    navigate(`/class/${className.toLowerCase().replace(/\s+/g, "-")}`);
  };

  return (
    <section className="class-section">

      <h2>📚 Choose Your Class</h2>

      <div className="class-grid">

        {classes.map((item) => (

          <div
            className="class-card"
            key={item.name}
            onClick={() => handleClick(item.name)}
          >

            <div className="class-icon">
              {item.icon}
            </div>

            <h3>{item.name}</h3>

            <p>Start Learning →</p>

          </div>

        ))}

      </div>

    </section>
  );
}

export default ClassSection;