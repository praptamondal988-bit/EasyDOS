function Hero() {
  return (
    <section className="hero">
      <div className="hero-content">
        <h1>বাংলাদেশের সেরা Learning Platform</h1>

        <p>
          ভিডিও ক্লাস, PDF, নোটস, Quiz এবং Model Test —
          সবকিছু এক জায়গায়।
        </p>

        <div className="hero-buttons">
          <button className="start-btn">
            🚀 Start Learning
          </button>

          <button className="explore-btn">
            📚 Explore Courses
          </button>
        </div>
      </div>
    </section>
  );
}

export default Hero;