import "./Header.css";

function Header() {
  return (
    <header className="header">

      <div className="logo">
        <span>Easy</span>DOS
      </div>

      <nav className="nav-menu">
        <a href="#">Home</a>
        <a href="#">Classes</a>
        <a href="#">Courses</a>
        <a href="#">Quiz</a>
        <a href="#">Notes</a>
      </nav>

      <button className="login-btn">
        Login
      </button>

    </header>
  );
}

export default Header;