import "./BannerSlider.css";

function BannerSlider() {

  return (
    <section className="banner-slider">

      <div className="banner-content">

        <span className="banner-badge">
          🚀 EasyDOS Premium
        </span>


        <h1>
          Master SSC with
          <br />
          <span>EasyDOS</span>
        </h1>


        <p>
          1000+ Video Classes & PDF Notes
          <br />
          Learn smarter, prepare better.
        </p>


        <button className="banner-btn">
          Start Learning →
        </button>


      </div>


    </section>
  );
}


export default BannerSlider;