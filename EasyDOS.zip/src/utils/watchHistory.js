const STORAGE_KEY = "easydos_watch_history";

export function getWatchHistory() {

  const data = localStorage.getItem(STORAGE_KEY);

  if (!data) return [];

  return JSON.parse(data);

}

export function saveWatch(video) {

  const history = getWatchHistory();

  const exists = history.find(
    (item) => item.youtubeId === video.youtubeId
  );

  if (!exists) {

    history.unshift(video);

    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify(history)
    );

  }

}