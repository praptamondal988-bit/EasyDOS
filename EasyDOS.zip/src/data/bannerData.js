const bannerData = [
  {
    id: 1,
    title: "Master SSC with EasyDOS",
    subtitle: "1000+ Video Classes & PDF Notes",
    button: "Start Learning",
    color: "#2563eb",
  },
  {
    id: 2,
    title: "Prepare for HSC",
    subtitle: "Live Classes, MCQ & CQ Practice",
    button: "Explore Courses",
    color: "#059669",
  },
  {
    id: 3,
    title: "Admission Preparation",
    subtitle: "Medical • Engineering • University",
    button: "Join Now",
    color: "#9333ea",
  },
];

export default bannerData;