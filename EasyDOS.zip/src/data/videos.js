const videos = {

  "class-9": {

    physics: [

      {
        id: 1,
        title: "Chapter 1 - Introduction",
        teacher: "Rahim Sir",
        duration: "18 min",
        youtubeId: "dQw4w9WgXcQ"
      },

      {
        id: 2,
        title: "Chapter 2 - Motion",
        teacher: "Rahim Sir",
        duration: "24 min",
        youtubeId: "aqz-KE-bpKQ"
      },

      {
        id: 3,
        title: "Chapter 3 - Force",
        teacher: "Rahim Sir",
        duration: "20 min",
        youtubeId: "ysz5S6PUM-U"
      }

    ]

  }

};

export default videos;