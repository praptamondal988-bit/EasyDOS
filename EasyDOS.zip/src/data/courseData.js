const courseData = {

  "class-9": {

    Physics: {

      chapters: [
        "Chapter 1 - Physical World",
        "Chapter 2 - Motion",
        "Chapter 3 - Force",
        "Chapter 4 - Work & Energy",
        "Chapter 5 - Pressure",
        "Chapter 6 - Heat",
        "Chapter 7 - Light"
      ],

      videos: [],

      pdfs: [],

      quiz: []

    },



    Chemistry: {

      chapters: [
        "Chapter 1 - Chemistry",
        "Chapter 2 - Atom",
        "Chapter 3 - Mole",
        "Chapter 4 - Periodic Table",
        "Chapter 5 - Chemical Bond"
      ],

      videos: [],

      pdfs: [],

      quiz: []

    },



    Biology: {

      chapters: [
        "Chapter 1 - Cell",
        "Chapter 2 - Tissue",
        "Chapter 3 - Plant",
        "Chapter 4 - Animal",
        "Chapter 5 - Human Body"
      ],

      videos: [],

      pdfs: [],

      quiz: []

    },



    Mathematics: {

      chapters: [
        "Chapter 1",
        "Chapter 2",
        "Chapter 3",
        "Chapter 4",
        "Chapter 5"
      ],

      videos: [],

      pdfs: [],

      quiz: []

    },



    ICT: {

      chapters: [
        "Chapter 1",
        "Chapter 2",
        "Chapter 3"
      ],

      videos: [],

      pdfs: [],

      quiz: []

    }

  }

};

export default courseData;