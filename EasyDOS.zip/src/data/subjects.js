const subjects = {

  "class-6": [
    "Bangla",
    "English",
    "Mathematics",
    "Science",
    "BGS",
    "ICT"
  ],

  "class-7": [
    "Bangla",
    "English",
    "Mathematics",
    "Science",
    "BGS",
    "ICT"
  ],

  "class-8": [
    "Bangla",
    "English",
    "Mathematics",
    "Science",
    "BGS",
    "ICT"
  ],

  "class-9": [
    "Bangla",
    "English",
    "General Mathematics",
    "Higher Mathematics",
    "Physics",
    "Chemistry",
    "Biology",
    "ICT",
    "BGS"
  ],

  "class-10": [
    "Bangla",
    "English",
    "General Mathematics",
    "Higher Mathematics",
    "Physics",
    "Chemistry",
    "Biology",
    "ICT",
    "BGS"
  ]

};

export default subjects;