import { Routes, Route } from "react-router-dom";

import Home from "./pages/Home";
import ClassPage from "./pages/ClassPage";
import SubjectPage from "./pages/SubjectPage";
import LearningPage from "./pages/LearningPage";
import VideoPage from "./pages/VideoPage";
import WatchPage from "./pages/WatchPage";

import "./App.css";

function App() {

  return (

    <Routes>

      <Route path="/" element={<Home />} />

      <Route
        path="/class/:className"
        element={<ClassPage />}
      />

      <Route
        path="/class/:className/:subjectName"
        element={<SubjectPage />}
      />

      <Route
        path="/class/:className/:subjectName/:feature"
        element={<LearningPage />}
      />

      <Route
        path="/videos/:className/:subjectName"
        element={<VideoPage />}
      />

      <Route
        path="/watch/:youtubeId"
        element={<WatchPage />}
      />

    </Routes>

  );

}

export default App;